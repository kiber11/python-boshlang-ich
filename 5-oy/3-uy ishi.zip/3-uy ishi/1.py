# from PyQt5.QtWidgets import (QWidget,QApplication,QLabel,QLineEdit,QTextEdit,QPushButton,QMainWindow,QVBoxLayout,QMessageBox)
# import wikipedia as wk
# from PyQt5.QtCore import Qt
# class window(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setWindowTitle("wikipedia")
#         self.line=QLineEdit(self)
#         self.line.setPlaceholderText("wikipedia so'rovi")
#         self.button=QPushButton("ma'lumotlarni olish",self)
#         self.button.clicked.connect(self.func)
#         self.layout=QVBoxLayout(self)
#         self.layout.addWidget(self.line)
#         self.layout.addWidget(self.button)
#         self.a=''
#         self.setLayout(self.layout)
#     def func(self):
#         try:
#             text=self.line.text()
#             wk.set_lang("uz")
#             self.a=wk.page(text)
#             win=window2(self.a,self.line.text())
#         except Exception as e:
#             self.message("Malumot topilmadi")
#     def message(self,xabar):
#         mes=QMessageBox("error",self)
#         mes.setText(xabar)
#         mes.setWindowIcon(QMessageBox.question)
#         mes.exec_()
# class window2(QMainWindow):
#     def __init__(self,matn,nomi):
#         super().__init__()
#         self.setWindowTitle("matn")
#         self.label2=QLabel(self)
#         self.label2.setAlignment(Qt.AlignCenter)
#         self.label2.setStyleSheet("font-size: 18px; margin-top: 20px;")
#         self.label2.setText(nomi)
#         central=QWidget()
#         self.layout2=QVBoxLayout(central)
#         self.layout2.addWidget(self.label2)
#         self.line2=QTextEdit(self)
#         self.line2.setReadOnly(True)
#         self.line2.setPlainText(matn)
#         self.layout2.addWidget(self.line2)
#         self.setLayout(self.layout2)
#         self.centralWidget(central)
#         self.show()
# app=QApplication([])
# win=window()
# win.show()
# app.exec_()

from PyQt5.QtWidgets import (QWidget, QApplication, QLabel, QLineEdit, QTextEdit, QPushButton, QMainWindow, QVBoxLayout, QMessageBox)
from PyQt5.QtCore import Qt
import wikipedia as wk

class window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Wikipedia")
        self.line = QLineEdit(self)
        self.line.setPlaceholderText("Wikipedia so'rovi")
        self.button = QPushButton("Ma'lumotlarni olish", self)
        self.button.clicked.connect(self.func)
        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.line)
        self.layout.addWidget(self.button)
        self.a = ''
        self.setLayout(self.layout)

    def func(self):
        try:
            text = self.line.text()
            wk.set_lang("uz")
            self.a = wk.page(text).content
            win = window2(self.a, self.line.text())
            win.show()
        except Exception as e:
            self.message("Ma'lumot topilmadi yoki xatolik yuz berdi.")

    def message(self, xabar):
        mes = QMessageBox(self)
        mes.setWindowTitle("Error")
        mes.setText(xabar)
        mes.exec_()

class window2(QMainWindow):
    def __init__(self, matn, nomi):
        super().__init__()
        self.setWindowTitle("Matn")
        self.label2 = QLabel(self)
        self.label2.setAlignment(Qt.AlignCenter)
        self.label2.setStyleSheet("font-size: 18px; margin-top: 20px;")
        self.label2.setText(nomi)

        self.line2 = QTextEdit(self)
        self.line2.setReadOnly(True)
        self.line2.setPlainText(matn)

        central_widget = QWidget()
        self.layout2 = QVBoxLayout(central_widget)
        self.layout2.addWidget(self.label2)
        self.layout2.addWidget(self.line2)
        self.setCentralWidget(central_widget)

app = QApplication([])
win = window()
win.show()
app.exec_()
