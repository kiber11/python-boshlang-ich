-- use dars_data;
-- select disease, count(*) AS disease_count
-- from bemorlar
-- group by disease
-- order by disease_count desc
-- limit 1;

-- select * from bemorlar
-- where age>40 and isMarried=1 and gender="Erkak";

-- select disease from bemorlar
-- where age<30 and isMarried=0 and gender="Ayol";

-- select gender, count(*) as soni from bemorlar
-- group by gender;

-- select * from bemorlar
-- where age<40 and disease="Qandli diabet"
-- order by age desc;

