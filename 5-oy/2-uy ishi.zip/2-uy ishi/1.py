from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QGridLayout, QVBoxLayout,QHBoxLayout,QMessageBox
from PyQt5.QtCore import Qt
class ShapeWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Shakllar")
        self.setFixedSize(400, 400)
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)
        self.UI()
    def UI(self):   
        
       
        self.button1 = QPushButton("1", self)
        #self.button1.setFixedSize(200,50)
        
        self.button2 = QPushButton("2", self)
        self.button3 = QPushButton("3", self)
        self.button4 = QPushButton("4", self)
        # self.orqaga=QPushButton("orqaga",self,clicked=self.UI)
        # self.orqaga.setGeometry(50,330,300,50)
        # self.orqaga.hide()
        self.button1.clicked.connect(self.draw_shape1)
        self.button2.clicked.connect(self.draw_shape2)
        self.button3.clicked.connect(self.draw_shape3)
        self.button4.clicked.connect(self.draw_shape4)

       
        self.layout.addWidget(self.button1)
        self.layout.addWidget(self.button2)
        self.layout.addWidget(self.button3)
        self.layout.addWidget(self.button4)
        #self.layout.addWidget(self.orqaga)
       
    
    
    def draw_shape1(self):
        self.button1.hide()
        self.button2.hide()
        self.button3.hide()
        self.button4.hide()
        #self.orqaga.show()
        button1=QPushButton("",self)
        button1.setGeometry(150,100,60,60)
        button1.setStyleSheet("background:blue;border-radius:12px;")

        button2=QPushButton("",self)
        button2.setGeometry(220,100,60,60)
        button2.setStyleSheet("background:blue;border-radius:12px;")

        button3=QPushButton("",self)
        button3.setGeometry(150,170,60,60)     
        button3.setStyleSheet("background:blue;border-radius:12px;")

        button4=QPushButton("",self)
        button4.setGeometry(150,240,60,60) 
        button4.setStyleSheet("background:blue;border-radius:12px;")
        button1.show()
        button2.show()
        button3.show()
        button4.show()
    def draw_shape2(self):
        self.button1.hide()
        self.button2.hide()
        self.button3.hide()
        self.button4.hide()
        #self.orqaga.show()
        button1=QPushButton("",self)
        button1.setGeometry(130,140,60,60)
        button1.setStyleSheet("background:blue;border-radius:12px;")

        button2=QPushButton("",self)
        button2.setGeometry(200,140,60,60)
        button2.setStyleSheet("background:blue;border-radius:12px;")

        button3=QPushButton("",self)
        button3.setGeometry(130,210,60,60)     
        button3.setStyleSheet("background:blue;border-radius:12px;")

        button4=QPushButton("",self)
        button4.setGeometry(200,210,60,60) 
        button4.setStyleSheet("background:blue;border-radius:12px;")
        button1.show()
        button2.show()
        button3.show()
        button4.show()
       

   
    def draw_shape3(self):
        self.button1.hide()
        self.button2.hide()
        self.button3.hide()
        self.button4.hide()
        #self.orqaga.show()
        button1=QPushButton("",self)
        button1.setGeometry(80,140,60,60)
        button1.setStyleSheet("background:blue;border-radius:12px;")

        button2=QPushButton("",self)
        button2.setGeometry(150,140,60,60)
        button2.setStyleSheet("background:blue;border-radius:12px;")

        button3=QPushButton("",self)
        button3.setGeometry(220,140,60,60)     
        button3.setStyleSheet("background:blue;border-radius:12px;")

        button4=QPushButton("",self)
        button4.setGeometry(290,140,60,60) 
        button4.setStyleSheet("background:blue;border-radius:12px;")
        button1.show()
        button2.show()
        button3.show()
        button4.show()
       

   
    def draw_shape4(self):
       
        self.button1.hide()
        self.button2.hide()
        self.button3.hide()
        self.button4.hide()
        #self.orqaga.show()
        button1=QPushButton("",self)
        button1.setGeometry(200,140,60,60)
        button1.setStyleSheet("background:blue;border-radius:12px;")

        button2=QPushButton("",self)
        button2.setGeometry(200,210,60,60)
        button2.setStyleSheet("background:blue;border-radius:12px;")

        button3=QPushButton("",self)
        button3.setGeometry(130,210,60,60)     
        button3.setStyleSheet("background:blue;border-radius:12px;")

        button4=QPushButton("",self)
        button4.setGeometry(130,280,60,60) 
        button4.setStyleSheet("background:blue;border-radius:12px;")
        button1.show()
        button2.show()
        button3.show()
        button4.show()
   
          
   
   


app = QApplication([])
window = ShapeWindow()
window.show()
app.exec_()
