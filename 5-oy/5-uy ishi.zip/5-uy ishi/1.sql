/*use dars_data;
create table talaba(
id int primary key,
ismi varchar(20),
stipendiya decimal(8,2),
kursi int);*/
/*insert into talaba(id,ismi,stipendiya,kursi)
values(1,"Abubakir",652000.00,3),
(2,"Abdujabbor",400000.00,2),
(3,"Majid",450000.00,1),
(4,"Sattor",502000.00,4),
(5,"Saidali",600000.00,4);*/

/*select ismi,stipendiya from talaba
where kursi=2;*/

/*select ismi,kursi from talaba
where stipendiya >=500000;*/

