/*select FirstName,LastName,City,Phone1,Website from customers
where Phone1 like "001%";*/

/*select * from customers
where Country="Uzbekistan";*/

/*select * from customers
where year(str_to_date(SubscriptionDate,"%Y-%m-%d"))=2020 and Country="Canada";*/