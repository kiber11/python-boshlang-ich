/*use dars_data;
create table xaridor(
ismi varchar(20),
familiyasi varchar(20),
yoshi int,
manzili text not null
);*/

/*insert into xaridor(ismi,familiyasi,yoshi,manzili)
values("Samandar","Samandarov",25,"Namangan"),
("Diyor","Hidoyatov",30,"Surxondaryo"),
("Mahmud","Asadov",15,"Namangan"),
("Sherali","Shukurov",19,"Toshkent"),
("Bahodir","Aliqulov",24,"Namangan");*/

/*select * from xaridor
where yoshi >20 and manzili="Namangan";*/

/*select * from xaridor
where ismi like 'D%' or ismi like 'B%';*/

