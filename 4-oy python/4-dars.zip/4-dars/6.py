# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 21:46:57 2024

@author: Shohruh
"""

import random
a=int(input('son kiriting: '))
lst=[]
b='emp'
for i in range(a):    
    c=random.randint(0,11)
    lst.append(b+str(c))
print(lst)