# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 21:06:37 2024

@author: Shohruh
"""
a=input('Biror narsa yozing: ')
b=[]
for i in a:
    b.append(i)
print(b)
    