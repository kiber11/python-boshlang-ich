# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 20:09:57 2024

@author: Shohruh
"""
a=int(input('a='))
b=int(input('b='))

juft_sonlar=[i for i in range(a,b) if i%2==0]
    
print(juft_sonlar)
