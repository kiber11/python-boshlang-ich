
class Talaba:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def get_info(self):
        print(f"Name: {self.name} \nAge: {self.age}")
class Kurs:
    talabalar_soni_py = 0
    talabalar_soni_jv = 0
    python_talabalar = []
    java_talabalar = []

    def __init__(self, kurs_name, kurs_teacher):
        self.kurs_name = kurs_name
        self.kurs_teacher = kurs_teacher

    def add(self, talaba):
        if self.kurs_name == "Python":
            Kurs.python_talabalar.append(talaba)
            Kurs.talabalar_soni_py += 1
        elif self.kurs_name == "Java":
            Kurs.java_talabalar.append(talaba)
            Kurs.talabalar_soni_jv += 1

   
    def delete_talaba(self, talaba):
        if self.kurs_name == "Python" and talaba in Kurs.python_talabalar:
            Kurs.python_talabalar.remove(talaba)
            Kurs.talabalar_soni_py -= 1
        elif self.kurs_name == "Java" and talaba in Kurs.java_talabalar:
            Kurs.java_talabalar.remove(talaba)
            Kurs.talabalar_soni_jv -= 1

    
    def get_info(self):
        if self.kurs_name == "Python":
            print(f"Kurs nomi: {self.kurs_name}")
            print(f"O'qituvchi: {self.kurs_teacher}")
            print(f"Talabalar soni: {Kurs.talabalar_soni_py}")
            print("Python kursidagi talabalar:")
            for talaba in Kurs.python_talabalar:
                talaba.get_info()
        elif self.kurs_name == "Java":
            print(f"Kurs nomi: {self.kurs_name}")
            print(f"O'qituvchi: {self.kurs_teacher}")
            print(f"Talabalar soni: {Kurs.talabalar_soni_jv}")
            print("Java kursidagi talabalar:")
            for talaba in Kurs.java_talabalar:
                talaba.get_info()
        print("-" * 30)



talaba1 = Talaba("Shohruh", 21)
talaba2 = Talaba("Azizbek", 22)
talaba3 = Talaba("Nurlan", 23)
talaba4 = Talaba("Abdulloh", 24)


python_kurs = Kurs("Python", "Avaz")
java_kurs = Kurs("Java", "Qurbonali")

python_kurs.add(talaba1)
python_kurs.add(talaba2)
java_kurs.add(talaba3)
java_kurs.add(talaba4)


python_kurs.get_info()
java_kurs.get_info()


python_kurs.delete_talaba(talaba1)  
java_kurs.delete_talaba(talaba3)    


python_kurs.get_info()
java_kurs.get_info()

# class Talaba:
#     python={}
#     java={}
#     def __init__(self,name,age):
#         self.name = name
#         self.age = age
#     def get_info(self):
#         print(f"Name:{self.name} \nAge:{self.age}")

# class Kurs(Talaba):
#     talabalar_soni_py = 0
#     talabalar_soni_jv = 0
#     talabalar=[]
#     def __init__(self,name,age,kurs_name,kurs_teacher):
#         super().__init__(name,age)
#         self.kurs_name = kurs_name
#         self.kurs_teacher = kurs_teacher
#         if self.kurs_name == "Python":
#             Kurs.talabalar_soni_py+=1
#         else:
#             Kurs.talabalar_soni_jv+=1
#         self.talabalar_soni = Kurs.talabalar_soni_py + Kurs.talabalar_soni_jv
#     def __add__(self,name,age,kurs_name):
#         if self.kurs_name=="Python":
#             Talaba.python[name]=age
#             self.talabalar_soni+=1
#             Kurs.talabalar_soni_py+=1
#             Kurs.talabalar.append(Talaba.python)
#         else:    
#             Talaba.java[name]=age
#             self.talabalar_soni+=1
#             Kurs.talabalar.append(Talaba.java)
#             Kurs.talabalar_soni_jv+=1
#     def delete_talaba(self,name,kurs_name):
#         if kurs_name=="Python":
#             self.talabalar.remove(Talaba.python[name])
#             self.talabalar_soni-=1
#         else:
#             self.talabalar.remove(Talaba.java[name])
#             self.talabalar_soni-=1
#     def get_info(self):
#         for talaba in self.talabalar:
#             print(f"{talaba.name},yoshi:{talaba.age}")
#             print(f"Talabalar soni:{self.talabalar_soni} \nKurs nomi:{self.kurs_name} \nO'qituvchi:{self.kurs_teacher}_")
#         print("-"*30)

# talaba1=Kurs("Shohruh",21,"Python","Avaz")
# talaba2=Kurs("Azizbek",22,"Python","Avaz")
# talaba3= Kurs("Nurlan",23,"Java","Qurbonali")
# talaba4=Kurs("Abdulloh",24,"Java","Qurbonali")
# talaba1.get_info()
# talaba2.get_info()
# talaba3.get_info()

# class Talaba:
#     python = {}
#     java = {}

#     def __init__(self, name, age):
#         self.name = name
#         self.age = age

#     def get_info(self):
#         print(f"Name: {self.name} \nAge: {self.age}")

# class Kurs:
#     talabalar_soni = 0

#     def __init__(self, kurs_name, kurs_teacher):
#         self.kurs_name = kurs_name
#         self.kurs_teacher = kurs_teacher
#         self.talabalar = []

#     def add(self, talaba):
#         if self.kurs_name == "Python":
#             Talaba.python[talaba.name] = talaba.age
#         else:
#             Talaba.java[talaba.name] = talaba.age
#         self.talabalar.append(talaba)
#         Kurs.talabalar_soni += 1

#     def delete_talaba(self, talaba):
#         if self.kurs_name == "Python":
#             Talaba.python.pop(talaba.name, None)
#         else:
#             Talaba.java.pop(talaba.name, None)
#         self.talabalar.remove(talaba)
#         Kurs.talabalar_soni -= 1

#     def get_info(self):
#         print(f"Kurs name: {self.kurs_name}\nKurs teacher: {self.kurs_teacher}\nTalabalar soni: {len(self.talabalar)}")
#         print("Talabalar ro'yxati:")
#         for talaba in self.talabalar:
#             print(f"- {talaba.name}, Yoshi: {talaba.age}")
#         print("-" * 30)

# # Talabalar yaratamiz
# talaba1 = Talaba("Shohruh", 21)
# talaba2 = Talaba("Azizbek", 22)
# talaba3 = Talaba("Nurlan", 23)
# talaba4 = Talaba("Abdulloh", 24)

# # Kurslar yaratamiz
# python_kurs = Kurs("Python", "Bahodir")
# java_kurs = Kurs("Java", "Qurbonali")

# # Talabalarni kurslarga qo'shamiz
# python_kurs.add(talaba1)
# python_kurs.add(talaba2)
# java_kurs.add(talaba3)
# java_kurs.add(talaba4)

# # Kurs haqida ma'lumot chiqaramiz
# python_kurs.get_info()
# java_kurs.get_info()

# # Talabalarni kursdan chiqaramiz
# python_kurs.delete_talaba(talaba1)
# java_kurs.delete_talaba(talaba3)

# # Kurs haqida ma'lumot chiqaramiz (talabalar chiqarilgandan keyin)
# python_kurs.get_info()
# java_kurs.get_info()

# # Talaba klassi
# class Talaba:
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age

# # Kurs klassi
# class Kurs:
#     def __init__(self, kurs_name, kurs_teacher):
#         self.kurs_name = kurs_name
#         self.kurs_teacher = kurs_teacher
#         self.talabalar_soni = 0
#         self.talabalar = []

#     # Talaba qo'shish metodi
#     def add(self, new_student):
#         self.talabalar.append(new_student)
#         self.talabalar_soni += 1

#     # Talabani kursdan o'chirish metodi
#     def delete(self, new_student):
#         self.talabalar = [talaba for talaba in self.talabalar if talaba.name != new_student.name]
#         self.talabalar_soni -= 1

#     # Kurs haqida ma'lumot chiqarish metodi
#     def info_kurs(self):
#         print(f"Kurs nomi: {self.kurs_name}")
#         print(f"O'qituvchi: {self.kurs_teacher}")
#         print(f"Talabalar soni: {self.talabalar_soni}")
#         print("Talabalar ro'yxati:")
#         for talaba in self.talabalar:
#             print(f"{talaba.name}, Yoshi: {talaba.age}")
#         print("-" * 30)

# # 10 ta talaba yaratamiz
# talabalar = [Talaba(f"Talaba{i+1}", 20+i) for i in range(10)]

# # 2 ta kurs e'lon qilamiz
# kurs1 = Kurs("Python", "Bahodir")
# kurs2 = Kurs("Java", "Otabek")

# # Har bir kursga 10 tadan talaba qo'shamiz
# for talaba in talabalar:
#     kurs1.add(talaba)
#     kurs2.add(talaba)

# # Kurslar haqida ma'lumot chiqaramiz
# kurs1.info_kurs()
# kurs2.info_kurs()

# # 2 ta talabani kursdan chiqaramiz
# kurs1.delete(talabalar[0])  # Talaba1 ni kurs1dan chiqaramiz
# kurs2.delete(talabalar[1])  # Talaba2 ni kurs2dan chiqaramiz

# # Kurslar haqida ma'lumotni qayta chiqaramiz
# kurs1.info_kurs()
# kurs2.info_kurs()
