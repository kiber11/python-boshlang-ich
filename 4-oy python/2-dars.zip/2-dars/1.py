n=int(input('son kiriting: '))
sum=0
i=1
while i<=n: 
    print(i,end=' ')
    sum=sum+i
    i+=1
print('\nThe Sum is :',sum)