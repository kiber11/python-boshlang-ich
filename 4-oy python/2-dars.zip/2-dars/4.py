n=int(input('son kiriting: '))
for n in range(n-1,0,-1):
    if n%2==0:
        print(n)
