
for i in range(10,100):
  
    bool=1
    for l in range(2,i):
        if i%l!=0:
            bool=1
        
        else:
            bool=0
            break
    if bool==1:
        print(i,end=' ')
    


       
           