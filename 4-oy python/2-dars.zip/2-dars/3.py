son=int(input('son kiriting: '))
raqamlar=str(son)
i=0
while i<len(raqamlar):
    print(raqamlar[i],end=' ')
    i+=1
