n=int(input('son kiriting: '))

while n!=0:
    if n%2==0:
        print(n,end=' ')
    n-=1