a=int(input('ikki xonali son kiriting: '))
print(f'{a//10}+{a%10}={a//10+a%10}')