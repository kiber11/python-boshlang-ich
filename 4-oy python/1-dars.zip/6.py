a=int(input('uch xonali son kiriting: '))
print((a%100*10)+(a//100))