a=int(input('uch xonali son kiriting: '))
print(f'{a//100}+{a//10%10}+{a%10}={a//100+a//10%10+a%10}')
