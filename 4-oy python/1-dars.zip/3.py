a=int(input('ikki xonali son kiriting: '))
print((a%10*10)+(a//10))