a=int(input('uch xonali son kiriting: '))
print((a%10*100)+(a//10%10*10)+(a//100))